# RT-WAL: Real-Time Execution Framework

**RT** execution + **W**rite-**A**head **L**ogging framework for embedded/industrial systems.

## Architecture

The framework follows strict layering with clear RT/non-RT separation:

```mermaid
graph TB
    subgraph "Application Layer"
        APPS[apps/<br/>brewery, minimal]
    end
    
    subgraph "Non-RT Domain"
        NONRT_DRAIN[nonrt/drain]
        NONRT_BACKEND[nonrt/backend]
        NONRT_DISP[nonrt/dispatcher]
        NONRT_ANAL[nonrt/analytics]
    end
    
    subgraph "RT Domain"
        RT_LOG[rt/logging<br/>publisher]
        RT_CTRL[rt/control<br/>pid, bangbang]
        RT_FSM[rt/fsm<br/>safety_fsm]
        RT_SENSOR[rt/sensor<br/>validator, filter]
        RT_TRANS[rt/transport<br/>spsc_ring, double_buffer]
    end
    
    subgraph "Execution Model"
        EXEC[exec/<br/>task, policies]
    end
    
    subgraph "Hardware Abstraction"
        HAL[hal/<br/>tick, gpio, adc, watchdog]
    end
    
    subgraph "Portability"
        SYS[sys/<br/>compiler, arch, fence]
    end
    
    subgraph "Core"
        CORE[core/<br/>types, result, concepts]
    end
    
    APPS --> NONRT_DRAIN
    APPS --> NONRT_BACKEND
    APPS --> RT_LOG
    APPS --> RT_CTRL
    
    NONRT_DRAIN --> RT_TRANS
    NONRT_BACKEND --> CORE
    NONRT_DISP --> RT_LOG
    NONRT_ANAL --> CORE
    
    RT_LOG --> RT_TRANS
    RT_CTRL --> RT_TRANS
    RT_FSM --> RT_TRANS
    RT_SENSOR --> CORE
    RT_TRANS --> SYS
    
    EXEC --> HAL
    EXEC --> SYS
    
    HAL --> SYS
    HAL --> CORE
    
    SYS --> CORE
    
    classDef rtClass fill:#ff9999,stroke:#cc0000,stroke-width:2px
    classDef nonrtClass fill:#99ccff,stroke:#0066cc,stroke-width:2px
    classDef coreClass fill:#99ff99,stroke:#00cc00,stroke-width:2px
    
    class RT_LOG,RT_CTRL,RT_FSM,RT_SENSOR,RT_TRANS rtClass
    class NONRT_DRAIN,NONRT_BACKEND,NONRT_DISP,NONRT_ANAL nonrtClass
    class CORE,SYS coreClass
```

### Key Principles

- **RT Domain** (red): bounded execution, no syscalls, no allocation
- **Non-RT Domain** (blue): persistence, analytics, diagnostics  
- **Core/Sys** (green): portable, platform-agnostic foundation

See [dependency_graph.md](docs/architecture/dependency_graph.md) for formal contracts.

## Features

- **RT-safe primitives**: SPSC ring, double buffer, lock-free exchange
- **Safety patterns**: generic FSM with WARN→LIMIT→SHED→PANIC escalation
- **Portable**: Cortex-M, Cortex-A, x86/x64 via HAL abstraction
- **Industrial-grade logging**: state snapshots, events, diagnostics
- **Showcase**: brewery control system as reference implementation

## Target Platforms

- ARM Cortex-M (STM32, etc.)
- ARM Cortex-A (Raspberry Pi, embedded Linux)
- x86/x64 (PC, industrial controllers)

## Getting Started

See [apps/minimal](apps/minimal) for basic usage example (coming soon).

For detailed architecture and contracts, refer to [docs/](docs/).

## Namespace

All framework components live in the `rtfw::` namespace.

## Status

Active R&D. Contracts-first development approach.

## License

TBD
