# Layering Model

This document describes the RT framework's layering model and design philosophy.

## Overview

The framework uses strict hierarchical layering to enforce separation of concerns and prevent RT contamination.

```
┌─────────────────────────────────────┐
│           apps/                      │  ← Showcase applications
├─────────────────────────────────────┤
│           nonrt/                     │  ← Persistence, analytics
├─────────────────────────────────────┤
│           rt/                        │  ← Real-time components
├─────────────────────────────────────┤
│           exec/                      │  ← Execution policies
├─────────────────────────────────────┤
│           hal/                       │  ← Hardware interfaces
├─────────────────────────────────────┤
│           sys/                       │  ← Portability layer
├─────────────────────────────────────┤
│           core/                      │  ← Foundation types
└─────────────────────────────────────┘
```

## Design Philosophy

### 1. Lower layers are more constrained

- `core` has the strictest requirements (pure C++, no platform deps)
- `sys` adds platform detection but no I/O
- `hal` defines I/O interfaces but no implementation
- `rt` adds real-time constraints
- `nonrt` relaxes constraints for persistence/analytics
- `apps` can use all layers freely

### 2. RT/non-RT boundary is physical

RT components (`rt/`) cannot depend on non-RT components (`nonrt/`).

Data flows RT → non-RT via:
- Lock-free rings (`rt/transport/spsc_ring.hpp`)
- Double buffers (`rt/transport/double_buffer.hpp`)

### 3. HAL is interface-only

`include/hal/` contains only abstract interfaces.

Platform-specific implementations live in `src/hal/<platform>/`.

This allows:
- Compile-time HAL selection
- Runtime HAL swapping (dependency injection)
- Mocking for tests

### 4. Apps are isolated

Framework layers (`core`, `sys`, `hal`, `exec`, `rt`, `nonrt`) must never depend on `apps`.

Showcase applications demonstrate best practices but don't dictate framework design.

## Dependency Enforcement

Dependencies are enforced via:

1. **Directory structure**: Lower layers physically separated from higher
2. **Include guards**: `rt/` headers don't include `nonrt/` headers
3. **Namespace policy**: Apps use `rtfw::`, don't extend it
4. **CMake targets**: Each layer is a separate library target

## See Also

- [dependency_graph.md](dependency_graph.md) - Formal dependency contracts
- [../contracts/](../contracts/) - Component-level invariants
